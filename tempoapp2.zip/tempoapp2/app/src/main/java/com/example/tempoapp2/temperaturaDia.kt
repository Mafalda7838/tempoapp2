package com.example.tempoapp2
class temperaturaDia (
    var temperatura: Int,
    var estado: String,
    var resource: Int
)
{}